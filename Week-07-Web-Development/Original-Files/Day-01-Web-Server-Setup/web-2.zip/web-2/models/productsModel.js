const products = [
  { name: "iPhone", price: 1111 },
  { name: "iPad", price: 2222 },
];

module.exports = {
  products,
};
