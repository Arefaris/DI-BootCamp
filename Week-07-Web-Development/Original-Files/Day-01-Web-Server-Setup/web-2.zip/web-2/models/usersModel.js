const users = [{"name":"Dan","email":"ddd@gmail.com","id":1}]

module.exports = {
    users
}

/** select, update, insert, delete */