const { Router } = require("express");
const router = Router();

const {getAllProducts, }= require("../controllers/productController.js")

router.get("/products", getAllProducts);


module.exports = router;