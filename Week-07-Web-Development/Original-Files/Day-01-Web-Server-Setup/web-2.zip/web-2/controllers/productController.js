const { products } = require("../models/productsModel.js");

const getAllProducts = (req, res)=>{
    res.json(products)
}

module.exports = {
    getAllProducts
};