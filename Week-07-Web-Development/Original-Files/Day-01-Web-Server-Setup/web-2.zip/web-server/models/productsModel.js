const products = [
    {name: 'iphone', price: 111},
    {name: 'ipad', price: 1121},
]

module.exports = products