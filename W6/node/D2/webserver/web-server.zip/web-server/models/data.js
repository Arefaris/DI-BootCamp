const users = [
  { id: 1, name: "John", email: "jjj@gmail.com" },
  { id: 2, name: "Anne", email: "aaa@gmail.com" },
  { id: 3, name: "Marry", email: "mmm@gmail.com" },
];

module.exports = {
  users,
};
